#ifndef ALGORITHMHISTORYTEST_H_
#define ALGORITHMHISTORYTEST_H_

#include <cxxtest/TestSuite.h>
#include "MantidAPI/Algorithm.h"
#include "MantidAPI/AlgorithmHistory.h"
#include "MantidAPI/WorkspaceProperty.h"
#include <sstream>

using namespace Mantid::API;
using namespace Mantid::Kernel;

// 'Empty' algorithm class for tests
class testalg : public Algorithm
{
public:
  testalg() : Algorithm() {}
  virtual ~testalg() {}
  const std::string name() const { return "testalg";} ///< Algorithm's name for identification
  const int version() const { return 1;} ///< Algorithm's version for identification
  const std::string category() const { return "Cat";} ///< Algorithm's category for identification

  void init()
  {
    declareProperty(new WorkspaceProperty<Workspace>("arg1_param","x",Direction::Input));
    declareProperty("arg2_param",23);
  }
  void exec() {}
};

class AlgorithmHistoryTest : public CxxTest::TestSuite
{
public:
  void testPopulate()
  {
    std::string correctOutput = "Algorithm: testalg ";
    correctOutput = correctOutput + "v1\n";
    correctOutput = correctOutput + "Execution Date: 2008-Feb-29 09:54:49\n";
    correctOutput = correctOutput + "Execution Duration: 14 seconds\n";
    correctOutput = correctOutput + "Parameters:\n";
    correctOutput = correctOutput + "  Name: arg1_param, ";
    correctOutput = correctOutput + "Value: 20, ";
    correctOutput = correctOutput + "Default?: No, ";
    correctOutput = correctOutput + "Direction: Input\n";
    correctOutput = correctOutput + "  Name: arg2_param, ";
    correctOutput = correctOutput + "Value: 23, ";
    correctOutput = correctOutput + "Default?: Yes, ";
    correctOutput = correctOutput + "Direction: Input\n";

    //set the time
    std::time_t rawtime;
    std::tm * timeinfo = new std::tm;
    timeinfo->tm_isdst = -1;

    /* The datetime must match that in the strng above */
    std::time ( &rawtime );
    timeinfo->tm_year = 108;
    timeinfo->tm_mon = 1;
    timeinfo->tm_mday = 29;
    timeinfo->tm_hour = 9;
    timeinfo->tm_min = 54;
    timeinfo->tm_sec = 49;
    std::time_t execTime = mktime ( timeinfo );

    // Not really much to test
    Algorithm *alg = new testalg;
    alg->initialize();
    alg->setPropertyValue("arg1_param","20");

    AlgorithmHistory AH(alg,execTime,14.0);
    //dump output to sting
    std::ostringstream output;
    output.exceptions( std::ios::failbit | std::ios::badbit );
    TS_ASSERT_THROWS_NOTHING(output << AH);
    TS_ASSERT_EQUALS(output.str(),correctOutput);

  }


};

#endif /* ALGORITHMHISTORYTEST_H_*/
