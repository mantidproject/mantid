#ifndef MANTID_KERNEL_INSTRUMENT_H_
#define MANTID_KERNEL_INSTRUMENT_H_

//----------------------------------------------------------------------
// Includes
//----------------------------------------------------------------------
#include "MantidKernel/Logger.h"
#include "MantidGeometry/CompAssembly.h"
#include "MantidGeometry/ObjComponent.h"
#include "MantidGeometry/Detector.h"
#include <string>
#include <ostream>

namespace Mantid
{
namespace API
{
/** @class Instrument Instrument.h

 	  Base Instrument Class.

    @author Nick Draper, ISIS, RAL
    @date 26/09/2007
    @author Anders Markvardsen, ISIS, RAL
    @date 1/4/2008

    Copyright &copy; 2007-8 STFC Rutherford Appleton Laboratory

    This file is part of Mantid.

    Mantid is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.

    Mantid is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
 	  along with this program.  If not, see <http://www.gnu.org/licenses/>.

    File change history is stored at: <https://svn.mantidproject.org/mantid/trunk/Code/Mantid>.
    Code Documentation is available at: <http://doxygen.mantidproject.org>
*/
class DLLExport Instrument : public Geometry::CompAssembly
{
public:
  ///String description of the type of component
  virtual std::string type() const { return "Instrument"; }

  Instrument();
  Instrument(const std::string& name);
  ///Virtual destructor
  virtual ~Instrument() {}

  Geometry::ObjComponent* getSource() const;
  Geometry::ObjComponent* getSample() const;
  Geometry::IDetector* getDetector(const int &detector_id) const;
  const double detectorTwoTheta(const Geometry::IDetector* const) const;

  /// mark a Component which has already been added to the Instrument (as a child comp.)
  /// to be 'the' samplePos Component. For now it is assumed that we have
  /// at most one of these.
  void markAsSamplePos(Geometry::ObjComponent*);

  /// mark a Component which has already been added to the Instrument (as a child comp.)
  /// to be 'the' source Component. For now it is assumed that we have
  /// at most one of these.
  void markAsSource(Geometry::ObjComponent*);

  /// mark a Component which has already been added to the Instrument (as a child comp.)
  /// to be a Detector component by adding it to _detectorCache
  void markAsDetector(Geometry::IDetector*);

  /// mark a Component which has already been added to the Instrument (as a child comp.)
  /// to be a monitor and also add it to _detectorCache for possible later retrieval
  void markAsMonitor(Geometry::IDetector*);

private:
  /// Private copy assignment operator
  Instrument& operator=(const Instrument&);
  /// Private copy constructor
  Instrument(const Instrument&);

  /// Static reference to the logger class
  static Kernel::Logger& g_log;

  Geometry::Component* getChild(const std::string& name) const;

  /// Map which holds detector-IDs and pointers to detector components
  std::map<int, Geometry::IDetector*> _detectorCache;

  /// Purpose to hold copy of source component. For now assumed to
  /// be just one component
  Geometry::ObjComponent* _sourceCache;

  /// Purpose to hold copy of samplePos component. For now assumed to
  /// be just one component
  Geometry::ObjComponent* _sampleCache;
};

} // namespace API
} //Namespace Mantid
#endif /*MANTID_KERNEL_INSTRUMENT_H_*/
