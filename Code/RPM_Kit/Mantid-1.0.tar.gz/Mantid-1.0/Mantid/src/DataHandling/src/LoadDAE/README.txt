Code from the IDC interface, a minimal socket interface to the DAE

The interface supports the old VMS raw data names e.g. NTC1, NSP1

Freddie Akeroyd
31/07/2008
