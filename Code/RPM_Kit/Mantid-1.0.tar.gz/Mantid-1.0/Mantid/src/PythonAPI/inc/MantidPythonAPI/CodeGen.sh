python $PYTHON_ROOT/site-packages/Pyste/pyste.py --gccxml-path=/usr/local/gccxml/default/bin/gccxml --module=libMantidPythonAPI --out=PythonWrapper.cpp PythonCodeGen.pyste 
